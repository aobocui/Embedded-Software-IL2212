# il2212_5_10
codes
All the .zip are in the release part

int_simplegrayscale_performance_debug.zip is the one that use int to transform data and use the simplest grayscale algorithm which is to 
get one channel from rgb. After I search the internet, I found there are different grayscale algorithm. This one might be the fastest one.
The code inside include performance and debug mode.

debug_performance_cpu0,1,2,3,4 are the codes that include both debug mode and performance mode but use the simplest grayscale algorithm.

multi_cpu0,1,2,3,4 are the codes that use the same grayscale algorithm as Haskell

ascii.h has been changed by Aobo according to the pointer's type.

https://www.youtube.com/watch?v=V3QLlD6k5hI&t=871s It is not clear after I combine different parts together. So I also hand in other seperate ones as follows

https://youtu.be/S9tD8vNpXT0 ---- single bare debug mode and performance mode

https://youtu.be/r8Rmk1U_po0 ---- rtos debug mode

https://youtu.be/DJLB5N8LxHQ ---- rtos performance mode

https://youtu.be/3O1VgLUQAMU ---- multi-core debug and performance mode using simple grayscale algorithm and int type pointer to transform data.

https://youtu.be/Pk69Z25pUwQ ---- multi-core performance mode using original grayscale algorithm





